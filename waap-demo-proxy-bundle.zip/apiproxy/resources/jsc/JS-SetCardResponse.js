response.content = '';
response.headers['Content-Type'] = 'application/json';
var dlpResponseJSON = JSON.parse(context.getVariable("dlpResponse.content"));
response.content = dlpResponseJSON.item.value;
